import React from 'react'
// import '../../hide.css';
import DashbordTables from "./DashbordTables";
const Dashboard2 = () => {
    return (
        <React.Fragment>
            <div className='dashboard_wrapper'>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-3 col-12">
                            <div className='user_dashboard_box'>
                                <h3>
                                    Total Companies
                                </h3>
                                <div className='user_box_title'>
                                    <h3>25</h3>
                                    <div className='user_data_descrip'>
                                        <div className='d-block'>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.99999 15.8334V4.16675M9.99999 4.16675L4.16666 10.0001M9.99999 4.16675L15.8333 10.0001" stroke="#6CE9A6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>  <p className='d-inline-block mb-0'>40%</p>
                                        </div>
                                        <span className='d-block text-white'>
                                            Last Month
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='row'>
                        <div className='col-md-6 col-lg-6 col-xl-6'>
                        <DashbordTables />
                    </div>
                    <div className='col-md-6 col-lg-6 col-xl-6'>
                        <div className="card p-3">
                            <div className="card-boy">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th colSpan={2}>Notification (25)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>You have a bug that needs to be the fix</td>
                                            <td className='text-muted'>20 Minuts Ago</td>
                                        </tr>
                                        <tr>
                                            <td>You have a bug that needs to be the fix</td>
                                            <td className='text-muted'>20 Minuts Ago</td>
                                        </tr>
                                        <tr>
                                            <td>You have a bug that needs to be the fix</td>
                                            <td className='text-muted'>20 Minuts Ago</td>
                                        </tr>
                                        <tr>
                                            <td>You have a bug that needs to be the fix</td>
                                            <td className='text-muted'>20 Minuts Ago</td>
                                        </tr>
                                        <tr>
                                            <td>You have a bug that needs to be the fix</td>
                                            <td className='text-muted'>20 Minuts Ago</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}

export default Dashboard2